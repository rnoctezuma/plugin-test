package nextflow.pipelinehelper

import groovy.transform.CompileStatic
import nextflow.plugin.BasePlugin
import nextflow.plugin.Scoped
import org.pf4j.PluginWrapper

@CompileStatic
class EntryPoint extends BasePlugin {

    EntryPoint(PluginWrapper wrapper) {
        super(wrapper)
    }
}
