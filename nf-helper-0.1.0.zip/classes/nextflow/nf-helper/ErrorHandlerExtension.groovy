package nextflow.pipelinehelper

import groovy.transform.CompileStatic
import groovy.util.logging.Slf4j
import nextflow.Session
import nextflow.plugin.extension.Function
import nextflow.plugin.extension.PluginExtensionPoint
import nextflow.processor.TaskConfig
import com.amazonaws.services.s3.AmazonS3
import com.amazonaws.services.sqs.AmazonSQS
import com.amazonaws.services.s3.AmazonS3ClientBuilder
import com.amazonaws.services.sqs.AmazonSQSClientBuilder
import com.amazonaws.auth.AWSStaticCredentialsProvider
import com.amazonaws.auth.BasicAWSCredentials
import com.amazonaws.services.sqs.model.SendMessageRequest

@Slf4j
@CompileStatic
class ErrorHandlerExtension extends PluginExtensionPoint {
    enum EventType {
        TASK_FAILED
    }
    
    private Session session
    private String aws_access_key_id
    private String aws_secret_access_key
    private String aws_default_region
    private String samples_bucket_name
    private String error_sqs_url
    private String error_sqs_group
    // nextflow.config eventHandling settings
    private String environment
    private String error_strategy
    private Integer max_display_error_lines
    private Integer backoff_retry_factor_ms
    private Integer max_retries

    private AmazonS3 s3Client
    private AmazonSQS sqsClient

    @Override
    protected void init(Session session) {
        this.session = session

        aws_access_key_id = System.getenv('AWS_ACCESS_KEY_ID')
        aws_secret_access_key = System.getenv('AWS_SECRET_ACCESS_KEY')
        aws_default_region = System.getenv('AWS_DEFAULT_REGION')
        samples_bucket_name = System.getenv('AWS_SAMPLES_BUCKET_NAME')
        error_sqs_url = System.getenv('ERROR_SQS_URL')
        error_sqs_group = System.getenv('ERROR_SQS_GROUP')
        // nextflow.config eventHandling settings
        environment = session.config.navigate('params.environment') as String
        error_strategy = session.config.navigate('params.eventHandling.errorStrategy') as String
        max_display_error_lines = session.config.navigate('params.eventHandling.maxDisplayErrorLines') as Integer
        backoff_retry_factor_ms = session.config.navigate('params.eventHandling.backoffRetryFactorMs') as Integer
        max_retries = session.config.navigate('params.eventHandling.maxRetries') as Integer

        s3Client = initS3Client()
        sqsClient = initSqsClient()
    }

    private AmazonS3 initS3Client() {
        BasicAWSCredentials awsCredentials = new BasicAWSCredentials(aws_access_key_id, aws_secret_access_key)

        return AmazonS3ClientBuilder.standard()
            .withRegion(aws_default_region)
            .withCredentials(new AWSStaticCredentialsProvider(awsCredentials))
            .build()
    }

    private AmazonSQS initSqsClient() {
        BasicAWSCredentials awsCredentials = new BasicAWSCredentials(aws_access_key_id, aws_secret_access_key)

        return AmazonSQSClientBuilder.standard()
            .withCredentials(new AWSStaticCredentialsProvider(awsCredentials))
            .withRegion(aws_default_region)
            .build()
    }

    private String cleanupErrorMessage(String errorMessage) {
        // Regular expression to match 'work/' followed by any characters until '.command.sh'
        def pattern = "work/[^/]+/.+?\\.command\\.sh"
        return errorMessage.replaceAll(pattern, 'work_file_name')
    }

    private String createDisplayErrorMessage(String errorMessage) {
        String[] lines = errorMessage.split("\n")

        if (lines.size() > (max_display_error_lines ?: 4)) {
            String result = (lines.take(2) + '...' + lines[-2..-1]).join("\n")
            return result
        }

        return errorMessage
    }

    private String getS3FileContent(String objectKey) {
        try {
            return s3Client.getObject(samples_bucket_name, objectKey).getObjectContent().getText()
        } catch (com.amazonaws.services.s3.model.AmazonS3Exception e) {
            if (e.errorCode == 'NoSuchKey') {
                return null
            }
            throw e
        }
    }

    private String createErrorMessage(String workDir, String status, String process) {
        def error = null
        def errorFileName = "${workDir}/.command.err"

        if (environment != 'local') {         
            def objectKey = errorFileName.substring(errorFileName.indexOf('work'))
            error = getS3FileContent(objectKey)            
        } else if (environment == 'local') {
            error = new File(errorFileName).text.trim()
        }

        if (error == null || error == '') {
            error = "exit status ${status}"
        }

        def errorMessage = "Process ${process} failed with error: ${error}"

        return errorMessage.toString()   
    }

    @Function
    String handleFailedTask(TaskConfig task) {
        try {
            if (task.exitStatus != 0) {
                String sampleId = task.get('tag') as String
                String workDir = task.get('workDir') as String
                String status = EventType.TASK_FAILED.name()
                String process = task.get('process') as String

                def errorMessage = createErrorMessage(workDir, status, process)

                def sqsMessage = "${status}|${sampleId}|${process}|${cleanupErrorMessage(errorMessage)}" +
                    "|${createDisplayErrorMessage(errorMessage)}"

                sqsClient.sendMessage(new SendMessageRequest()
                    .withQueueUrl(error_sqs_url)
                    .withMessageBody(sqsMessage)
                    .withMessageGroupId(error_sqs_group)
                );
            }

            Integer attempt = task.getAttempt()

            if (attempt <= (max_retries ?: 0)) {
                // TODO: retry only if task.exitCode is infrastructural error, no need to retry on busyness logic error
                // backoff for a bit, then retry
                Double randomnessFactor = (Math.random() * 0.5) + 0.5

                sleep((Math.pow(2, attempt) * (backoff_retry_factor_ms ?: 1000) * randomnessFactor) as long)
                return 'retry'
            }
        } catch (Exception e) {
            log.error "Exception while handling failed task: ${e}"
        }

        return (error_strategy ?: 'terminate')
    }
}