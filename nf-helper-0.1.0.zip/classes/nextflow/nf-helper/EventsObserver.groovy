package nextflow.pipelinehelper

import groovy.transform.CompileStatic
import groovy.util.logging.Slf4j
import nextflow.Session
import nextflow.trace.TraceObserver
import nextflow.trace.TraceRecord
import nextflow.processor.TaskHandler
import nextflow.script.params.OutParam
import java.nio.file.Path
import com.amazonaws.auth.BasicAWSCredentials
import com.amazonaws.auth.AWSStaticCredentialsProvider
import com.amazonaws.services.s3.AmazonS3
import com.amazonaws.services.sqs.AmazonSQS
import com.amazonaws.services.s3.model.SetObjectTaggingRequest
import com.amazonaws.services.s3.model.Tag
import com.amazonaws.services.s3.model.ObjectTagging
import com.amazonaws.services.s3.AmazonS3ClientBuilder
import com.amazonaws.services.sqs.AmazonSQSClientBuilder
import com.amazonaws.services.sqs.model.SendMessageRequest
import com.amazonaws.services.s3.model.GetObjectMetadataRequest
import com.amazonaws.services.s3.model.ListObjectsV2Request

@Slf4j
@CompileStatic
class EventsObserver implements TraceObserver {

    private String aws_access_key_id
    private String aws_secret_access_key
    private String aws_default_region
    private String samples_bucket_name
    private String upload_by_tag
    private String error_sqs_url
    private String error_sqs_group

    private AmazonS3 s3Client
    private AmazonSQS sqsClient

    EventsObserver() {
        aws_access_key_id = System.getenv('AWS_ACCESS_KEY_ID')
        aws_secret_access_key = System.getenv('AWS_SECRET_ACCESS_KEY')
        aws_default_region = System.getenv('AWS_DEFAULT_REGION')
        samples_bucket_name = System.getenv('AWS_SAMPLES_BUCKET_NAME')
        upload_by_tag = System.getenv('NEXTFLOW_UPLOAD_BY')
        error_sqs_url = System.getenv('ERROR_SQS_URL')
        error_sqs_group = System.getenv('ERROR_SQS_GROUP')

        s3Client = initS3Client()
        sqsClient = initSqsClient()
    }

    private AmazonS3 initS3Client() {
        BasicAWSCredentials awsCredentials = new BasicAWSCredentials(aws_access_key_id, aws_secret_access_key)

        return AmazonS3ClientBuilder.standard()
            .withRegion(aws_default_region)
            .withCredentials(new AWSStaticCredentialsProvider(awsCredentials))
            .build()
    }

    private AmazonSQS initSqsClient() {
        BasicAWSCredentials awsCredentials = new BasicAWSCredentials(aws_access_key_id, aws_secret_access_key)

        return AmazonSQSClientBuilder.standard()
            .withCredentials(new AWSStaticCredentialsProvider(awsCredentials))
            .withRegion(aws_default_region)
            .build()
    }

    private void addS3FileTags(String bucketName, String objectKey) {
        List<Tag> tagList = [new Tag("upload_by", upload_by_tag)]
        ObjectTagging objectTagging = new ObjectTagging(tagList)
        SetObjectTaggingRequest request = new SetObjectTaggingRequest(bucketName, objectKey, objectTagging)

        try {
            s3Client.setObjectTagging(request)
        } catch (Exception e) {
            log.error "Failed to add tags to S3 object: $objectKey in bucket: $bucketName | Error - $e"
        }
    }

    private void setTagsForProcessOutputFiles(Map<OutParam,Object> outputs) {      
        def s3_keys = outputs.values()
            .collect { it.toString() }
            .unique()
            .findAll { it.contains(samples_bucket_name) }
            .collect { it.startsWith('/') ? it[1..-1] : it }

        def typedS3Objects = getTypedS3Objects(s3_keys)
        def unknownPaths = typedS3Objects['unknown']

        if (!unknownPaths.isEmpty()) {
            log.error "Next objects ${unknownPaths} in bucket $samples_bucket_name were not tagged!"
        }

        def folderPaths = typedS3Objects['folder']
        List<String> folderKeys = []

        try {
            folderPaths.each { folderPath ->       
                def listObjectsRequest = new ListObjectsV2Request()
                    .withBucketName(samples_bucket_name)
                    .withPrefix(folderPath)
                    .withMaxKeys(1000)

                def listObjectsResponse = s3Client.listObjectsV2(listObjectsRequest)

                listObjectsResponse.getObjectSummaries().each { objectSummary ->
                    if (!objectSummary.getKey().endsWith('/')) {
                        folderKeys << objectSummary.getKey()
                    }
                }
            }
        } catch (Exception e) {
            log.error "Error during getting folder files | Error - ${e}"
        }

        def filePaths = typedS3Objects['file']
        def filesToBeTagged = (filePaths + folderKeys).unique()

        filesToBeTagged.each { fileToBeTagged ->
            addS3FileTags(samples_bucket_name, fileToBeTagged)
        }
    }

    private Map<String, List<String>> getTypedS3Objects(List<String> s3Paths) {
        def result = [
            'file'   : [] as List<String>,
            'folder' : [] as List<String>,
            'unknown': [] as List<String>
        ]
        
        s3Paths.each { s3Path ->
            def parts = s3Path.split('/', 2)
            def bucketName = parts[0]
            def objectKey = parts[1]

            try {
                def metadata = s3Client.getObjectMetadata(new GetObjectMetadataRequest(bucketName, objectKey))
                result['file'] << objectKey
            } catch (Exception e) {
                try {
                    def folderMetadata = s3Client.getObjectMetadata(new GetObjectMetadataRequest(bucketName, objectKey + '/'))
                    result['folder'] << objectKey
                } catch (Exception folderException) {
                    result['unknown'] << objectKey
                }
            }
        }
        return result
    }

    private void sendSqsSuccessMessage(TraceRecord trace) {
        def sample_id = trace.get('tag')
        def process_name = trace.getProcessName()

        def sqsMessage = "TASK_SUCCEEDED|${sample_id}|${process_name}"

        sqsClient.sendMessage(new SendMessageRequest()
            .withQueueUrl(error_sqs_url)
            .withMessageBody(sqsMessage)
            .withMessageGroupId(error_sqs_group)
        );
    }

    @Override
    void onProcessComplete(TaskHandler handler, TraceRecord trace) {
        def processStatus = handler.getStatusString()

        if (processStatus != 'COMPLETED') {
            def process_name = trace.getProcessName()
            log.error "File tags will not be added because '${process_name}' process failed"
            return
        }
        
        setTagsForProcessOutputFiles(handler.task.outputs)
        sendSqsSuccessMessage(trace)
    }
}
